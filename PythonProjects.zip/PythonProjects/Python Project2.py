import time
from datetime import datetime
import sys

list_route_one = ["Singapore", "Johor", "Kuala Lumpur", "Butterworth", "Kedah", "Perlis", "Thailand"]
list_route_two = ["Singapore", "Johor", "Kuala Lumpur", "Terengganu", "Kelantan", "Thailand"]
list_flow_route_one = " - ".join(list_route_one)
list_flow_route_two = " - ".join(list_route_two)
list_stopover_station = ["Johor", "Kelantan", "Perlis", "Kuala Lumpur"]

list_status = []
list_route_one_arrival = []
list_route_one_departure = []
list_route_two_arrival = []
list_route_two_departure = []
list_route_one_turnaround = []
list_route_two_turnaround = []
list_stopover = []
list_route_one_duration = []
list_route_two_duration = []
list_prompt = []


def wait():
    time.sleep(1)


def invalid():
    print("Please select a valid option.")
    wait()


def validate_valid(prompt, exist, message):
    if prompt not in exist:
        print(f"Please enter a valid {message} again.")
        wait()
        return False
    return True


def validate_time(prompt):
    try:
        datetime.strptime(prompt, "%H:%M:%S")
        return True
    except ValueError:
        print("Please enter the time again using the correct format (hh:mm:ss).")
        wait()
        return False


def validate_digit(prompt):
    if not prompt.isdigit():
        print("Only integer will be acceptable.")
        wait()
        return False
    return True


def validate_exist(prompt, exist, message):
    if prompt in exist:
        print(f"The {message} is already exist, please try again.")
        wait()
        return False
    return True


def validate_arrival_departure(larger, smaller):
    if larger <= smaller:
        print(f"The following time must be larger.")
        wait()
        return False
    return True


def start():
    print("Welcome to Malaya Railway (KTM).")
    wait()
    home_page()


def home_page():
    while True:
        print("HOME PAGE")
        print("1. Admin.")
        print("2. User.")
        role_choice = input("Please select your role: ")
        if role_choice == "1":
            admin_login()
        elif role_choice == "2":
            user_page()
        else:
            invalid()


def admin_login():
    attempt = 0
    while True:
        check_username = input("Please enter your username: ")
        check_password = input("Please enter your password: ")
        if not (check_username == "admin" and check_password == "admin1"):
            attempt += 1
            if attempt == 3:
                print("For entering the incorrect username or password thrice, you are terminated from the system.")
                wait()
                sys.exit()
            else:
                print("The username or password is incorrect, please try again.")
                continue
        else:
            print("Login successful.")
            wait()
            admin_page()


def admin_page():
    while True:
        print("ADMIN PAGE")
        print("1. Create / update timetable.")
        print("2. Add / remove stations.")
        print("3. Create / update turnaround time.")
        print("4. Create / update stopover time.")
        print("5. Back.")
        admin_choice = input("Please select an option (1/2/3/4/5): ")
        if admin_choice == "1":
            manage_timetable()
        elif admin_choice == "2":
            manage_station()
        elif admin_choice == "3":
            manage_turnaround_time()
        elif admin_choice == "4":
            manage_stopover_time()
        elif admin_choice == "5":
            home_page()
        else:
            invalid()


def manage_timetable():
    if "Created timetable" not in list_status:
        print(f"Route 1: {list_flow_route_one}")
        for stations_names in range(len(list_route_one)):
            while True:
                arrival_time = input(f"Please enter the arrival time of {list_route_one[stations_names]} station: ")
                list_prompt.append(arrival_time)
                if stations_names != 0:
                    if not validate_arrival_departure(list_prompt[-1], list_route_one_departure[stations_names - 1]):
                        continue
                if not validate_time(arrival_time):
                    continue
                else:
                    list_route_one_arrival.append(arrival_time)
                    while True:
                        departure_time = input(f"Please enter the departure time of {list_route_one[stations_names]} station: ")
                        list_prompt.append(departure_time)
                        if not validate_time(departure_time):
                            continue
                        elif not validate_arrival_departure(list_prompt[-1], list_route_one_arrival[stations_names]):
                            continue
                        else:
                            list_route_one_departure.append(departure_time)
                            break
                    break
        print(f"Route 2: {list_flow_route_two}")
        list_route_two_arrival.extend(list_route_one_arrival[:3])
        list_route_two_departure.extend(list_route_one_departure[:3])
        for stations_names in range(len(list_route_two) - 3):
            while True:
                arrival_time = input(f"Please enter the arrival time of {list_route_two[stations_names + 3]} station: ")
                list_prompt.append(arrival_time)
                if not validate_time(arrival_time):
                    continue
                if stations_names == 0:
                    if not validate_arrival_departure(list_prompt[-1], list_route_two_departure[stations_names - 1]):
                        continue
                else:
                    if not validate_arrival_departure(list_prompt[-1], list_route_two_departure[2]):
                        continue
                list_route_two_arrival.append(arrival_time)
                while True:
                    departure_time = input(f"Please enter the departure time of {list_route_two[stations_names + 3]} station: ")
                    list_prompt.append(departure_time)
                    if not validate_time(departure_time):
                        continue
                    elif not validate_arrival_departure(list_prompt[-1], list_route_two_arrival[stations_names]):
                        continue
                    list_route_two_departure.append(departure_time)
                    break
                break
        list_status.append("Created timetable")
        print("Timetable created successfully.")
        wait()
        view_timetable()
        admin_page()
    else:
        print("This is the initial timetable: ")
        wait()
        view_timetable()
        while True:
            timetable_update_choice = input("Do you want to update route(1) or route(2)? (1/2): ")
            if timetable_update_choice == "1":
                while True:
                    print(f"Available stations: {", ".join(list_route_one)}")
                    timetable_update_with_station = input("Enter the station that you want to update: ")
                    if not validate_valid(timetable_update_with_station, list_route_one, "station"):
                        continue
                    else:
                        index_station_route_one = list_route_one.index(timetable_update_with_station)
                        while True:
                            new_arrival_time = input(f"Please enter the new arrival time of {list_route_one[index_station_route_one]} station: ")
                            if not validate_time(new_arrival_time):
                                continue
                            elif index_station_route_one != 0:
                                if not validate_arrival_departure(new_arrival_time, list_route_one_departure[index_station_route_one - 1]):
                                    continue
                            else:
                                list_route_one_arrival[index_station_route_one] = new_arrival_time
                                while True:
                                    new_departure_time = input(f"Please enter the new departure time of {list_route_one[index_station_route_one]} station: ")
                                    if not validate_time(new_departure_time):
                                        continue
                                    elif index_station_route_one != 0:
                                        if not validate_arrival_departure(new_departure_time, list_route_one_arrival[index_station_route_one - 1]):
                                            continue
                                    else:
                                        list_route_one_departure[index_station_route_one] = new_departure_time
                                        if 0 <= index_station_route_one <= 2:
                                            list_route_two_arrival[index_station_route_one] = new_arrival_time
                                            list_route_two_departure[index_station_route_one] = new_departure_time
                                        print("Timetable updated successfully.")
                                        wait()
                                        view_timetable()
                                        admin_page()
                                        break
                                break
                        break
            elif timetable_update_choice == "2":
                while True:
                    print(f"Available stations: {", ".join(list_route_two)}")
                    timetable_update_with_station = input("Enter the station that you want to update: ")
                    if not validate_valid(timetable_update_with_station, list_route_two, "station"):
                        continue
                    else:
                        index_station_route_two = list_route_two.index(timetable_update_with_station)
                        while True:
                            new_arrival_time = input(f"Please enter the new arrival time of {list_route_two[index_station_route_two]} station: ")
                            if not validate_time(new_arrival_time):
                                continue
                            else:
                                list_route_two_arrival[index_station_route_two] = new_arrival_time
                                while True:
                                    new_departure_time = input(f"Please enter the new departure time of {list_route_one[index_station_route_two]} station: ")
                                    if not validate_time(new_departure_time):
                                        continue
                                    else:
                                        list_route_two_departure[index_station_route_two] = new_departure_time
                                        if 0 <= index_station_route_two <= 2:
                                            list_route_one_arrival[index_station_route_two] = new_arrival_time
                                            list_route_one_departure[index_station_route_two] = new_departure_time
                                        print("Timetable updated successfully.")
                                        wait()
                                        view_timetable()
                                        admin_page()
                                        break
                                break
                        break
            else:
                invalid()
                continue


def manage_station():
    if "Created timetable" not in list_status:
        print("Please create timetable first to prevent any errors.")
        wait()
        admin_page()
    while True:
        timetable_update_choice = input("Do you want to update route(1) or route(2) (1/2): ")
        if timetable_update_choice == "1":
            print(f"Available stations: {", ".join(list_route_one)}")
            while True:
                station_choice = input("Do you want to (a)dd or (r)emove station? (a/r): ")
                if station_choice == "a":
                    while True:
                        add_station = input("Enter the station you want to add: ")
                        if not validate_exist(add_station, list_route_one, "station"):
                            continue
                        else:
                            list_route_one.append(add_station)
                            while True:
                                arrival_time = input(f"Please enter the arrival time of {add_station} station: ")
                                if not validate_time(arrival_time):
                                    continue
                                elif not validate_arrival_departure(arrival_time, list_route_one_arrival[-1]):
                                    continue
                                else:
                                    list_route_one_arrival.append(arrival_time)
                                    while True:
                                        departure_time = input(f"Please enter the departure time of {add_station} station: ")
                                        if not validate_time(departure_time):
                                            continue
                                        elif not validate_arrival_departure(departure_time, list_route_one_departure[-1]):
                                            continue
                                        else:
                                            list_route_one_departure.append(departure_time)
                                            print("Station added successfully.")
                                            wait()
                                            view_timetable()
                                            admin_page()
                                            break
                                    break
                            break
                elif station_choice == "r":
                    while True:
                        remove_station = input("Enter the station you want to remove: ")
                        if not validate_valid(remove_station, list_route_one, "station"):
                            continue
                        else:
                            index_remove_station = list_route_one.index(remove_station)
                            list_route_one.pop(index_remove_station)
                            list_route_one_arrival.pop(index_remove_station)
                            list_route_one_departure.pop(index_remove_station)
                            print("Station remove successfully.")
                            wait()
                            view_timetable()
                            admin_page()
                            break
                else:
                    invalid()
        elif timetable_update_choice == "2":
            print(f"Available stations: {", ".join(list_route_two)}")
            while True:
                station_choice = input("Do you want to (a)dd or (r)emove station? (a/r): ")
                if station_choice == "a":
                    while True:
                        add_station = input("Enter the station you want to add: ")
                        if not validate_exist(add_station, list_route_two, "station"):
                            continue
                        else:
                            list_route_two.append(add_station)
                            while True:
                                arrival_time = input(f"Please enter the arrival time of {add_station} station: ")
                                if not validate_time(arrival_time):
                                    continue
                                else:
                                    list_route_two_arrival.append(arrival_time)
                                    while True:
                                        departure_time = input(f"Please enter the departure time of {add_station} station: ")
                                        if not validate_time(departure_time):
                                            continue
                                        else:
                                            list_route_two_departure.append(departure_time)
                                            print("Station added successfully.")
                                            wait()
                                            view_timetable()
                                            admin_page()
                                            break
                                    break
                            break
                elif station_choice == "r":
                    while True:
                        remove_station = input("Enter the station you want to remove: ")
                        if not validate_valid(remove_station, list_route_two, "station"):
                            continue
                        else:
                            index_remove_station = list_route_two.index(remove_station)
                            list_route_two.pop(index_remove_station)
                            list_route_two_arrival.pop(index_remove_station)
                            list_route_two_departure.pop(index_remove_station)
                            print("Station remove successfully.")
                            wait()
                            view_timetable()
                            admin_page()
                            break
        else:
            invalid()
            continue


def manage_turnaround_time():
    if "Created turnaround" not in list_status:
        print(f"Route 1:\n{list_flow_route_one}")
        wait()
        for stations_names in list_route_one:
            while True:
                safety_cleaning_checks = input(f"Please enter the time for safety cleaning checks in {stations_names} station (second): ")
                if not validate_digit(safety_cleaning_checks):
                    continue
                else:
                    while True:
                        refuel = input(f"Please enter the time for refuel (second) in {stations_names} station: ")
                        if not validate_digit(refuel):
                            continue
                        else:
                            while True:
                                change_track = input(f"Please enter the time for change_track (second) in {stations_names} station: ")
                                if not validate_digit(change_track):
                                    continue
                                else:
                                    turnaround_time = int(safety_cleaning_checks) + int(refuel) + int(change_track)
                                    list_route_one_turnaround.append(turnaround_time)
                                    break
                            break
                    break
        list_route_two_turnaround.extend(list_route_one_turnaround[:3])
        print(f"Route 2:\n{list_flow_route_two}")
        for stations_names in list_route_two[2:]:
            while True:
                safety_cleaning_checks = input(f"Please enter the time for safety cleaning checks in {stations_names} station (second): ")
                if not validate_digit(safety_cleaning_checks):
                    continue
                else:
                    while True:
                        refuel = input(f"Please enter the time for refuel (second) in {stations_names} station: ")
                        if not validate_digit(refuel):
                            continue
                        else:
                            while True:
                                change_track = input(f"Please enter the time for change_track (second) in {stations_names} station: ")
                                if not validate_digit(change_track):
                                    continue
                                else:
                                    turnaround_time = int(safety_cleaning_checks) + int(refuel) + int(change_track)
                                    list_route_two_turnaround.append(turnaround_time)
                                    break
                            break
                    break
        print("Turnaround time created successfully.")
        wait()
        list_status.append("Created turnaround")
        view_turnaround_time()
        wait()
        admin_page()
    else:
        print("This is the initial turnaround time: ")
        wait()
        view_turnaround_time()
        while True:
            turnaround_update_choice = input("Do you want to update route(1) or route(2)? (1/2): ")
            if turnaround_update_choice == "1":
                while True:
                    print(f"Available station: {", ".join(list_route_one)}")
                    station_update_turnaround = input("Enter the station that you want to update the turnaround time: ")
                    if not validate_valid(station_update_turnaround, list_route_one, "station"):
                        continue
                    else:
                        while True:
                            new_safety_cleaning_checks = input(f"Please enter the new time for safety cleaning checks in {station_update_turnaround} station (second): ")
                            if not validate_digit(new_safety_cleaning_checks):
                                continue
                            else:
                                while True:
                                    new_refuel = input(f"Please enter the new time for refuel (second) in {station_update_turnaround} station: ")
                                    if not validate_digit(new_refuel):
                                        continue
                                    else:
                                        while True:
                                            new_change_track = input(
                                                f"Please enter the new time for change_track (second) in {station_update_turnaround} station: ")
                                            if not validate_digit(new_change_track):
                                                continue
                                            else:
                                                new_turnaround_time = int(new_safety_cleaning_checks) + int(new_refuel) + int(new_change_track)
                                                index_new_turnaround_time = list_route_one.index(
                                                    station_update_turnaround)
                                                list_route_one_turnaround[
                                                    index_new_turnaround_time] = new_turnaround_time
                                                if 0 <= index_new_turnaround_time <= 2:
                                                    list_route_one_turnaround[
                                                        index_new_turnaround_time] = new_turnaround_time
                                                print("Turnaround time updated successfully.")
                                                wait()
                                                view_turnaround_time()
                                                wait()
                                                admin_page()
                                                break
                                        break
                                break
            elif turnaround_update_choice == "2":
                while True:
                    print(f"Available station: {", ".join(list_route_two)}")
                    station_update_turnaround = input("Enter the station that you want to update the turnaround time: ")
                    if not validate_valid(station_update_turnaround, list_route_two, "station"):
                        continue
                    else:
                        while True:
                            new_safety_cleaning_checks = input(f"Please enter the new time for safety cleaning checks in {station_update_turnaround} station (second): ")
                            if not validate_digit(new_safety_cleaning_checks):
                                continue
                            else:
                                while True:
                                    new_refuel = input(f"Please enter the new time for refuel (second) in {station_update_turnaround} station: ")
                                    if not validate_digit(new_refuel):
                                        continue
                                    else:
                                        while True:
                                            new_change_track = input(f"Please enter the new time for change_track (second) in {station_update_turnaround} station: ")
                                            if not validate_digit(new_change_track):
                                                continue
                                            else:
                                                new_turnaround_time = int(new_safety_cleaning_checks) + int(new_refuel) + int(new_change_track)
                                                index_new_turnaround_time = list_route_one.index(
                                                    station_update_turnaround)
                                                list_route_two_turnaround[
                                                    index_new_turnaround_time] = new_turnaround_time
                                                if 0 <= index_new_turnaround_time <= 2:
                                                    list_route_one_turnaround[
                                                        index_new_turnaround_time] = new_turnaround_time
                                                print("Turnaround time updated successfully.")
                                                wait()
                                                view_turnaround_time()
                                                wait()
                                                admin_page()
                                                break
                                        break
                                break
            else:
                invalid()
                continue


def manage_stopover_time():
    if "Created stopover" not in list_status:
        for stations_name in list_stopover_station[:-1]:
            while True:
                stopover_time_others = input(f"Please enter the time for Immigration Check-Point in {stations_name} station (second): ")
                if not validate_digit(stopover_time_others):
                    continue
                else:
                    list_stopover.append(stopover_time_others)
                    break
        else:
            while True:
                stopover_time_kl = input("Please enter the stopover time for Kuala Lumpur (second): ")
                if not validate_digit(stopover_time_kl):
                    continue
                else:
                    list_stopover.append(stopover_time_kl)
                    print("Stopover time created successfully.")
                    wait()
                    list_status.append("Created stopover")
                    view_stopover_time()
                    wait()
                    admin_page()
    else:
        print("This is the initial stopover time: ")
        wait()
        view_stopover_time()
        while True:
            print(f"Available stations: {", ".join(list_stopover_station)}")
            stopover_update_with_station = input("Enter the station that you want to update: ")
            if not validate_valid(stopover_update_with_station, list_stopover_station, "station"):
                continue
            else:
                while True:
                    new_stopover_time = input(f"Please enter the new stopover time in {stopover_update_with_station} station (second): ")
                    if not validate_digit(new_stopover_time):
                        continue
                    else:
                        index_stopover_station = list_stopover_station.index(stopover_update_with_station)
                        list_stopover[index_stopover_station] = new_stopover_time
                        print("Stopover time updated successfully.")
                        wait()
                        view_stopover_time()
                        wait()
                        admin_page()
                        break
                break


def user_page():
    print("USER PAGE")
    while True:
        print("1. View timetable.")
        print("2. View travelling duration.")
        print("3. View turnaround time.")
        print("4. View stopover time.")
        print("5. Back.")
        user_choice = input("Please select an option (1/2/3/4/5): ")
        if user_choice == "1":
            view_timetable()
        elif user_choice == "2":
            view_travelling_duration()
        elif user_choice == "3":
            view_turnaround_time()
        elif user_choice == "4":
            view_stopover_time()
        elif user_choice == "5":
            home_page()
        else:
            invalid()


def view_timetable():
    if "Created timetable" not in list_status:
        print("Timetable has yet to be created.")
        wait()
        user_page()
    print("Route 1: ")
    print(f"{"Station":<15}{"Arrival time":<15}{"Departure time":<15}")
    for index_print_timetable in range(len(list_route_one)):
        print(f"{list_route_one[index_print_timetable]:<15}{list_route_one_arrival[index_print_timetable]:<15}"
              f"{list_route_one_departure[index_print_timetable]:<15}")
    wait()
    print("\nRoute 2: ")
    print(f"{"Station":<15}{"Arrival time":<15}{"Departure time":<15}")
    for index_print_timetable in range(len(list_route_two)):
        print(f"{list_route_two[index_print_timetable]:<15}{list_route_two_arrival[index_print_timetable]:<15}"
              f"{list_route_two_departure[index_print_timetable]:<15}")
    print("")
    wait()


def view_travelling_duration():
    if "Created timetable" not in list_status:
        print("Timetable has yet to be created.")
        wait()
        user_page()
    for route_one_departure in range(len(list_route_one) - 1):
        route_one_duration = (int("".join((list_route_one_arrival[route_one_departure + 1]).split(":")))
                              - int("".join((list_route_one_departure[route_one_departure]).split(":"))))
        list_route_one_duration.append(route_one_duration)
    for route_two_departure in range(len(list_route_two) - 1):
        route_two_duration = (int("".join((list_route_two_arrival[route_two_departure + 1]).split(":")))
                              - int("".join((list_route_two_departure[route_two_departure]).split(":"))))
        list_route_two_duration.append(route_two_duration)
    print("Route 1: ")
    print(f"{"From":<15}{"To":<15}{"Duration (second)":<15}")
    for index_print_duration in range(len(list_route_one) - 1):
        print(f"{list_route_one[index_print_duration]:<15}{list_route_one[index_print_duration + 1]:<15}"
              f"{list_route_one_duration[index_print_duration]:<20}")
    print("\nRoute 2: ")
    print(f"{"From":<15}{"To":<15}{"Duration (second)":<15}")
    for index_print_duration in range(len(list_route_two) - 1):
        print(f"{list_route_two[index_print_duration]:<15}{list_route_two[index_print_duration + 1]:<15}"
              f"{list_route_two_duration[index_print_duration]:<20}")
    print("")
    wait()


def view_turnaround_time():
    if "Created turnaround" not in list_status:
        print("Turnaround time has yet to be created.")
        wait()
        user_page()
    print("Route 1: ")
    print(f"{"Station":<15}{"Turnaround time (second)":<15}")
    for index_print_turnaround in range(len(list_route_one)):
        print(f"{list_route_one[index_print_turnaround]:<15}{list_route_one_turnaround[index_print_turnaround]:<20}")
    wait()
    print("\nRoute 2: ")
    print(f"{"Station":<15}{"Turnaround time (second)":<15}")
    for index_print_turnaround in range(len(list_route_two)):
        print(f"{list_route_two[index_print_turnaround]:<15}{list_route_two_turnaround[index_print_turnaround]:<20}")
    print("")
    wait()


def view_stopover_time():
    if "Created stopover" not in list_status:
        print("Stopover time has yet to be created.")
        wait()
        user_page()
    print(f"{"Station":<15}{"Stopover time (second)":<15}")
    for index_print_stopover in range(len(list_stopover_station)):
        print(f"{list_stopover_station[index_print_stopover]:<15}{list_stopover[index_print_stopover]:<15}")
    print("")
    wait()


start()
