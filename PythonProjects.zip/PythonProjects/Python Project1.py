import time
import sys
import datetime

list_name = []
list_address = []
list_email = []
list_contact = []
list_gender = []
list_birthday = []
list_username = []
list_password = []
list_sums_grocery_price = []
list_orders_name = []
list_orders_price = []
list_total_customer = []
list_first_orders_name = []
list_second_orders_name = []
list_third_orders_name = []
list_fourth_orders_name = []
list_fifth_orders_name = []
list_orders_customer = []

type_gender = ["Boy", "Girl", "Other"]
list_grocery_name = ["Apple", "Cabbage", "Mister Potato"]
list_grocery_expire_date = ["30/5/2025", "23/6/2025", "31/12/2025"]
list_grocery_price = ["3.00", "10.00", "5.50"]
list_grocery_specification = ["0.500", "2.150", "1.100"]


def wait():
    time.sleep(1)


def end():
    print("Exiting the program..")
    print("Goodbye, have a nice day.")
    wait()
    sys.exit()


def invalid():
    print("Please enter again using a valid input.")
    wait()


def validate_empty(prompt, message):
    if prompt == "":
        print(f"The {message} cannot be empty, please enter a real {message}.")
        wait()
        return False
    return True


def validate_exist(prompt, exist, message):
    if prompt in exist:
        print(f"The {message} is already existed, please enter another {message}.")
        wait()
        return False
    return True


def validate_login():
    print("The username or password is incorrect, please try again.")
    wait()
    return True


def validate_customer_login(attempt):
    if attempt != 3:
        validate_login()
    else:
        print("Failure to login thrice, you have been terminated from the system.")
        wait()
        sys.exit()


def validate_email(prompt):
    if "@" not in prompt.strip():
        print("Please enter a valid email address with \"@\".")
        wait()
        return False
    return True


def validate_digit(prompt):
    if not prompt.isdigit():
        print("Only integers will be accepted, please enter again.")
        wait()
        return False
    return True


def validate_valid(prompt, exist, message):
    if prompt not in exist:
        print(f"Please enter a valid {message}.")
        wait()
        return False
    return True


def validate_date(prompt):
    try:
        datetime.datetime.strptime(prompt, "%d/%m/%Y")
    except ValueError:
        print("Please enter again using the correct format.")
        wait()
        return False
    return True


def validate_password(prompt):
    if len(prompt) < 8:
        print("The password must contains at least 8 characters, please try again.")
        wait()
        return False
    return True


def validate_rewrite_password(initial_prompt, current_prompt):
    if not current_prompt == initial_prompt:
        print("Please rewrite again using correct password.")
        wait()
        return False
    return True


def validate_price(prompt):
    if not (prompt.strip().replace(".", "", 1)).isdigit():
        print("The price must be float or integer, please enter again.")
        wait()
        return False
    return True


def validate_weight(prompt):
    if not (prompt.strip().replace(".", "", 1)).isdigit():
        print("The specification, weight must be float or integer, please enter again.")
        wait()
        return False
    return True


def start():
    print("Welcome to FRESH Market (FM) Sdn Bhd.")
    wait()
    home_page()


def home_page():
    while True:
        print("HOME PAGE: ")
        print("1. Admin.")
        print("2. Customer.")
        role = input("Please state your role (1 / 2): ")
        if role.strip() == "1":
            admin()
        elif role.strip() == "2":
            customer()
        else:
            invalid()


def admin():
    print("ADMIN: ")
    attempt = 0
    while True:
        print("Username = 1")
        print("Password = 1")
        admin_username = input("Please enter your username: ")
        admin_password = input("Please enter your password: ")
        if not (admin_username.strip() == "1" and admin_password.strip() == "1"):
            attempt += 1
            if not attempt == 3:
                validate_login()
            else:
                print("Failure to login thrice, you have been terminated from the system.")
                wait()
                sys.exit()
        else:
            print("Welcome back, 1.")
            wait()
            admin_page()


def admin_page():
    while True:
        print("ADMIN PAGE: ")
        print("1. Add grocery details.")
        print("2. Delete grocery details.")
        print("3. Update grocery details.")
        print("4. View groceries details.")
        print("5. Search specific grocery details.")
        print("6. View all customers orders.")
        print("7. Search specific customer orders.")
        print("8. Back.")
        print("9. Exit.")
        admin_choice = input("Please choose an option (1 / 2 / 3 / 4 / 5 / 6 / 7 / 8 / 9): ")
        if admin_choice.strip() == "1":
            add_grocery()
        elif admin_choice.strip() == "2":
            delete_grocery()
        elif admin_choice.strip() == "3":
            update_grocery()
        elif admin_choice.strip() == "4":
            view_groceries()
        elif admin_choice.strip() == "5":
            search_grocery()
        elif admin_choice.strip() == "6":
            view_all()
        elif admin_choice.strip() == "7":
            view_specific()
        elif admin_choice.strip() == "8":
            home_page()
        elif admin_choice.strip() == "9":
            end()
        else:
            invalid()


def add_grocery():
    print("This is the available groceries details: ")
    wait()
    view_groceries()
    while True:
        add_grocery_name = input("Please enter a grocery name: ")
        if not validate_empty(add_grocery_name, "grocery name"):
            continue
        elif not validate_exist(add_grocery_name, list_grocery_name, "grocery name"):
            continue
        list_grocery_name.append(add_grocery_name)
        while True:
            add_grocery_expire_date = input("Please enter the expire date (dd/mm/yyyy): ")
            if not validate_date(add_grocery_expire_date):
                continue
            list_grocery_expire_date.append(add_grocery_expire_date)
            while True:
                str_add_grocery_price = input("Please enter the price (RM): ")
                if not validate_price(str_add_grocery_price):
                    continue
                float_add_grocery_price = float(str_add_grocery_price)
                add_grocery_price = ("{:.2f}".format(float_add_grocery_price))
                list_grocery_price.append(add_grocery_price)
                while True:
                    str_add_grocery_specification = input("Please enter the specification, the weight (kg): ")
                    if not validate_weight(str_add_grocery_specification):
                        continue
                    add_grocery_specification = "{:.4f}".format(float(str_add_grocery_specification))
                    list_grocery_specification.append(add_grocery_specification)
                    index_latest_grocery_name = len(list_grocery_name) - 1
                    print(f"The {list_grocery_name[index_latest_grocery_name]} details have been added successfully.")
                    wait()
                    view_groceries()
                    wait()
                    break
                break
            break
        break


def view_groceries():
    print(f"{"Name":<20}{"Expire Date (dd/mm/yyyy)":<30}{"Price (RM)":<20}{"Specification, weight (kg)":<20}\n")
    for index_print_grocery_name in range(len(list_grocery_name)):
        print(f"{list_grocery_name[index_print_grocery_name]:<20}"
              f"{list_grocery_expire_date[index_print_grocery_name]:<30}"
              f"{list_grocery_price[index_print_grocery_name]:<20}"
              f"{list_grocery_specification[index_print_grocery_name]:<20}\n")
    wait()


def delete_grocery():
    print("This is the available groceries details: ")
    wait()
    view_groceries()
    all_groceries_name = ", ".join(list_grocery_name)
    while True:
        print(f"Available groceries name: {all_groceries_name}")
        delete_with_name = input("Please enter the groceries name that you want to delete: ")
        if not validate_valid(delete_with_name, list_grocery_name, "grocery name"):
            continue
        else:
            index_delete_grocery_name = list_grocery_name.index(delete_with_name)
            list_grocery_name.pop(index_delete_grocery_name)
            list_grocery_expire_date.pop(index_delete_grocery_name)
            list_grocery_price.pop(index_delete_grocery_name)
            list_grocery_specification.pop(index_delete_grocery_name)
            print(f"The details of {delete_with_name} is deleted successfully.")
            wait()
            view_groceries()
            wait()
            break


def update_grocery():
    print("This is the available groceries details: ")
    wait()
    view_groceries()
    all_groceries_name = ", ".join(list_grocery_name)
    while True:
        print(f"Available groceries name: {all_groceries_name}")
        update_with_name = input("Please enter the groceries name that you want to update: ")
        if not validate_valid(update_with_name, list_grocery_name, "grocery name"):
            continue
        else:
            while True:
                print("UPDATE GROCERY: ")
                print("1. Name.")
                print("2. Expire date.")
                print("3. Price")
                print("4. Specification.")
                update_choice = input("Please enter the detail that you want to update (1 / 2 / 3 / 4): ")
                if update_choice == "1":
                    update_name(update_with_name)
                elif update_choice == "2":
                    update_expire_date(update_with_name)
                elif update_choice == "3":
                    update_price(update_with_name)
                elif update_choice == "4":
                    update_specification(update_with_name)
                else:
                    invalid()


def update_name(update_with_name):
    while True:
        new_name = input("Please enter a new grocery name: ")
        if not validate_empty(new_name, "grocery name"):
            continue
        elif not validate_exist(new_name, list_grocery_name, "grocery name"):
            continue
        else:
            index_update_grocery_name = list_grocery_name.index(update_with_name)
            list_grocery_name[index_update_grocery_name] = new_name
            print(f"The initial name has been replaced with {new_name} successfully.")
            wait()
            view_groceries()
            wait()
            admin_page()


def update_expire_date(update_with_name):
    while True:
        new_expire_date = input("Please enter a new grocery expire date (dd/mm/yyyy): ")
        if not validate_date(new_expire_date):
            continue
        else:
            index_update_grocery_name = list_grocery_name.index(update_with_name)
            list_grocery_expire_date[index_update_grocery_name] = new_expire_date
            print(f"The initial expire date has been replaced with {new_expire_date} successfully.")
            wait()
            view_groceries()
            wait()
            admin_page()


def update_price(update_with_name):
    while True:
        str_new_price = input("Please enter a new price (RM): ")
        if not validate_price(str_new_price):
            continue
        else:
            float_new_price = float(str_new_price)
            new_price = ("{:.2f}".format(float_new_price))
            index_update_grocery_name = list_grocery_name.index(update_with_name)
            list_grocery_price[index_update_grocery_name] = new_price
            print(f"The initial price (RM) has been replaced with {new_price} successfully.")
            wait()
            view_groceries()
            wait()
            admin_page()


def update_specification(update_with_name):
    while True:
        str_new_specification = input("Please enter a new specification, the weight (kg): ")
        if not validate_weight(str_new_specification):
            continue
        else:
            new_specification = "{:.4f}".format(float(str_new_specification))
            index_update_grocery_name = list_grocery_name.index(update_with_name)
            list_grocery_specification[index_update_grocery_name] = new_specification
            print(f"The initial specification, weight (kg) has been replaced with {new_specification} successfully.")
            wait()
            view_groceries()
            wait()
            admin_page()


def search_grocery():
    all_groceries_name = ", ".join(list_grocery_name)
    while True:
        print(f"Available groceries name: {all_groceries_name}")
        search_with_name = input("Please enter the groceries name that you want to search: ")
        if not validate_valid(search_with_name, list_grocery_name, "grocery name"):
            continue
        else:
            print(f"{"Name":<20}{"Expire Date (dd/mm/yyyy)":<30}{"Price (RM)":<20}{"Specification, weight (kg)":<20}\n")
            index_print_grocery_name = list_grocery_name.index(search_with_name)
            print(f"{list_grocery_name[index_print_grocery_name]:<20}"
                  f"{list_grocery_expire_date[index_print_grocery_name]:<30}"
                  f"{list_grocery_price[index_print_grocery_name]:<20}"
                  f"{list_grocery_specification[index_print_grocery_name]:<20}\n")
            wait()
            break


def type_orders_name(index_orders_customers):
    if index_orders_customers == 0:
        if not list_first_orders_name:
            return "nothing"
        else:
            return ", ".join(list_first_orders_name)
    elif index_orders_customers == 1:
        if not list_second_orders_name:
            return "nothing"
        else:
            return ", ".join(list_second_orders_name)
    elif index_orders_customers == 2:
        if not list_third_orders_name:
            return "nothing"
        else:
            return ", ".join(list_third_orders_name)
    elif index_orders_customers == 3:
        if not list_fourth_orders_name:
            return "nothing"
        else:
            return ", ".join(list_fourth_orders_name)
    else:
        if not list_fifth_orders_name:
            return "nothing"
        else:
            return ", ".join(list_fifth_orders_name)


def view_all():
    if len(list_orders_customer) == 0:
        print("No one have yet to purchase anything.")
        wait()
    else:
        for index_all_cus in range(len(list_orders_customer)):
            print(f"Customer {index_all_cus + 1}, {list_orders_customer[index_all_cus]} bought "
                  f"{type_orders_name(index_all_cus)}")
            wait()


def view_specific():
    if len(list_orders_customer) == 0:
        print("No one have yet to purchase anything.")
        wait()
    else:
        all_username = ", ".join(list_orders_customer)
        while True:
            print(f"Available username: {all_username}")
            search_with_username = input("Please enter the username that you want to view the orders: ")
            if not validate_valid(search_with_username, list_orders_customer, "username"):
                continue
            else:
                index_orders_customers = list_orders_customer.index(search_with_username)
                print(f"{search_with_username} bought {type_orders_name(index_orders_customers)}.")
                wait()
                break


def customer():
    while True:
        print("CUSTOMER: ")
        print("1. Register an account.")
        print("2. Login to the system.")
        print("3. View Groceries details.")
        print("4. Back.")
        print("5. Exit.")
        customer_choice = input("Please choose an option (1 / 2 / 3 / 4 / 5): ")
        if customer_choice.strip() == "1":
            customer_register()
        elif customer_choice.strip() == "2":
            customer_login()
        elif customer_choice.strip() == "3":
            view_groceries()
        elif customer_choice.strip() == "4":
            home_page()
        elif customer_choice.strip() == "5":
            end()
        else:
            invalid()


def customer_register():
    while True:
        name = input("Please enter your name: ")
        if not validate_empty(name, "name"):
            continue
        list_name.append(name)
        while True:
            address = input("Please enter your address: ")
            if not validate_empty(address, "address"):
                continue
            list_address.append(address)
            while True:
                email = input("Please enter your email address (with @): ")
                if not validate_email(email):
                    continue
                elif not validate_exist(email, list_email, "email address"):
                    continue
                list_email.append(email)
                while True:
                    contact = input("Please enter your contact number (only numbers): ")
                    if not validate_digit(contact):
                        continue
                    elif not validate_exist(contact, list_contact, "contact number"):
                        continue
                    list_contact.append(contact)
                    while True:
                        gender = input("Please enter your gender type (Boy / Girl / Other): ")
                        if not validate_valid(gender, type_gender, "gender"):
                            continue
                        list_gender.append(gender)
                        while True:
                            birthday = input("Please enter your date of birth (dd/mm/yyyy): ")
                            if not validate_date(birthday):
                                continue
                            list_birthday.append(birthday)
                            while True:
                                username = input("Please enter a username: ")
                                if not validate_empty(username, "username"):
                                    continue
                                elif not validate_exist(username, list_username, "username"):
                                    continue
                                list_username.append(username)
                                while True:
                                    password = input("Please enter a password (At least 8 characters): ")
                                    if not validate_password(password):
                                        continue
                                    list_password.append(password)
                                    while True:
                                        rewrite_password = input("Please rewrite the password: ")
                                        if not validate_rewrite_password(password, rewrite_password):
                                            continue
                                        else:
                                            print("You have complete the registration successfully.")
                                            wait()
                                            customer()


def customer_login():
    attempt = 0
    while True:
        if len(list_username) == 0:
            print("Please register first before trying to login.")
            wait()
            break
        else:
            customer_username = input("Please enter your username: ")
            customer_password = input("Please enter your password: ")
            if customer_username.strip() not in list_username:
                attempt += 1
                validate_customer_login(attempt)
            else:
                index_username = list_username.index(customer_username.strip())
                if customer_password.strip() != list_password[index_username]:
                    attempt += 1
                    validate_customer_login(attempt)
                else:
                    print(f"Welcome, {customer_username}.")
                    wait()
                    customer_page()


def customer_page():
    while True:
        print("CUSTOMER PAGE: ")
        print("1. View groceries details.")
        print("2. Place groceries orders, do payment, and view orders.")
        print("3. View personal information.")
        print("4. Back.")
        print("5. Exit.")
        customer_choice = input("Please choose an option (1 / 2 / 3 / 4 / 5): ")
        if customer_choice.strip() == "1":
            view_groceries()
        elif customer_choice.strip() == "2":
            orders()
        elif customer_choice.strip() == "3":
            view_information()
        elif customer_choice.strip() == "4":
            customer()
        elif customer_choice.strip() == "5":
            end()
        else:
            invalid()


def orders():
    if list_fifth_orders_name:
        print("Sorry, the total customers is currently fulled.")
        wait()
        customer_page()
    else:
        while True:
            print("ORDER PAGE: ")
            print("1. View groceries details.")
            print("2. Place orders.")
            print("3. Pay.")
            print("4. View orders.")
            print("5. Back.")
            orders_choice = input("Please choose an option (1 / 2 / 3 / 4 / 5): ")
            if orders_choice.strip() == "1":
                view_groceries()
            elif orders_choice.strip() == "2":
                all_groceries_name = ", ".join(list_grocery_name)
                while True:
                    print(f"Available groceries name: {all_groceries_name}")
                    order_name = input("Please enter the grocery name that you want to order: ")
                    if not validate_valid(order_name, list_grocery_name, "grocery name"):
                        continue
                    else:
                        index_order_grocery_name = list_grocery_name.index(order_name)
                        list_orders_name.append(order_name)
                        list_orders_price.append(list_grocery_price[index_order_grocery_name])
                        print(f"{order_name} added to your cart successfully.")
                        wait()
                        break
            elif orders_choice.strip() == "3":
                if len(list_orders_name) == 0:
                    print("Please place grocery orders first.")
                    wait()
                else:
                    for int_convert in list_orders_price:
                        list_sums_grocery_price.append(int(float(int_convert)))
                    total_price = sum(list_sums_grocery_price)
                    print(f"The total price for your orders is summed as RM{total_price}.")
                    all_usernames = ", ".join(list_username)
                    while True:
                        print(f"Available usernames: {all_usernames}")
                        orders_customer = input("Please enter your username: ")
                        if not validate_valid(orders_customer, list_username, "username"):
                            continue
                        else:
                            list_orders_customer.append(orders_customer)
                            list_total_customer.append("1")
                            if len(list_total_customer) == 1:
                                list_first_orders_name.extend(list_orders_name)
                            elif len(list_total_customer) == 2:
                                list_second_orders_name.extend(list_orders_name)
                            elif len(list_total_customer) == 3:
                                list_third_orders_name.extend(list_orders_name)
                            elif len(list_total_customer) == 4:
                                list_fourth_orders_name.extend(list_orders_name)
                            elif len(list_total_customer) == 5:
                                list_fifth_orders_name.extend(list_orders_name)
                            list_orders_name.clear()
                            list_orders_price.clear()
                            print("Thank you for your purchasing...!")
                            wait()
                            customer_page()
            elif orders_choice.strip() == "4":
                if len(list_orders_name) == 0:
                    print("You have yet to order anything.")
                else:
                    print(f"{"Name":<15}{"Price (RM)":<15}\n")
                    for index_print_grocery_order_name in range(len(list_orders_name)):
                        print(f"{list_orders_name[index_print_grocery_order_name]:<15}"
                              f"{list_orders_price[index_print_grocery_order_name]:<15}\n")
                    wait()
            elif orders_choice.strip() == "5":
                customer_page()
            else:
                invalid()
            wait()


def view_information():
    all_usernames = ", ".join(list_username)
    print(f"Available usernames: {all_usernames}")
    while True:
        view_with_username = input("Please enter your username: ")
        if not validate_valid(view_with_username, list_username, "username"):
            continue
        else:
            print(f"{"Name":<15}{"Address":<15}{"Email Address":<20}{"Contact Number":<20}{"Gender":<15}"
                  f"{"Date_Of_Birth":<20}{"Username":<15}{"Password":<15}\n")
            index_username = list_username.index(view_with_username)
            print(f"{list_name[index_username]:<15}{list_address[index_username]:<15}{list_email[index_username]:<20}"
                  f"{list_contact[index_username]:<20}{list_gender[index_username]:<15}"
                  f"{list_birthday[index_username]:<20}{list_username[index_username]:<15}"
                  f"{list_password[index_username]:<15}\n")
            wait()
            break


start()
