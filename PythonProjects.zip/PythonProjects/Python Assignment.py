# GEERTHANAA A/P MANIRAJU
# TP076503 (TP076314, TP076259, TP075870, TP076691)

# Import.
import time
import sys
import os

# Create empty list.
registeredUsername = []
registeredPassword = []
store = []
existQuantity = []
existUnitPrice = []
existReceiveItem = []
existReceivedQuantity = []
existDistributionCode = []
existDistributionItem = []
existDistributionQuantity = []
existDistributionHospital = []
existSupplierCode = []
typesSupplierName = []
existSupplierName = []
existHospitalCode = []
existHospitalName = []
quantityTracking = []
itemTracking = []
codeTracking = []
numOfLength = []
duplicateDistributionCode = []
duplicateDistributionHospital = []
duplicateDistributionQuantity = []

# Initialize list for PPE code, items.
ppeCode = ["HC", "FS", "SC", "MS", "GL", "GW"]
ppeName = ["Head Cover", "Face Shield", "Shoe Covers", "Mask", "Gloves", "Gown"]


# End program.
def end():
    print("Exiting the program ... Goodbye!!")
    wait()
    sys.exit()


# Message and wait.
def wait():
    time.sleep(1)


# Validation when the input is invalid.
def invalid():
    print("Invalid input, please try again.")
    wait()


# Validation when prompt is NONE.
def validationEmpty(answer, prompt):
    if not answer:
        print(f"The {prompt} cannot be empty, please enter again.")
        wait()
        return False
    return True


# Validation when prompt is duplicated, already exist.
def validationDuplicate(answer, existed, prompt):
    if answer in existed:
        print(f"The {prompt} is already exist, please enter again with different inputs.")
        wait()
        return False
    return True


# Validation when prompt does not match the requirement.
def validationValid(answer, existed, prompt):
    if answer not in existed:
        print(f"Please enter a valid {prompt}.")
        wait()
        return False
    return True


# Validation when prompt is not integer.
def validationDigit(answer):
    if not answer.isdigit():
        print("Only integer will be acceptable.")
        wait()
        return False
    return True


# Start program.
def start():
    ppe = createFile("ppe.txt")
    ppe.write(f"{"Item Code":<15}{"Item Name":<15}{"Quantity":<15}{"Supplier Code":<20}{"Unit Price (RM)":<15}\n")
    ppe.close()
    print("ppe.txt has been successfully created.")
    wait()
    homePage()


# Create File.
def createFile(fileName):
    if os.path.exists(fileName):
        os.remove(fileName)
    callFile = open(fileName, "w")
    return callFile


# Home page.
def homePage():
    print("Welcome to PPE Inventory Management System.")
    wait()
    while True:
        print("HOME PAGE")
        print("1. Register account.")
        print("2. Login account.")
        print("3. Exit..")
        homePages = input("Please choose an option (1 / 2 / 3): ")
        if homePages == "1":
            register()
        elif homePages == "2":
            login()
        elif homePages == "3":
            end()
        else:
            invalid()


# Register account.
def register():
    if not len(registeredUsername) < 4:
        print("There are already have four controllers registered.")
        wait()
    else:
        while True:
            username = input("Set your username: ")
            if validationDuplicate(answer=username, existed=registeredUsername, prompt="username"):
                if validationEmpty(answer=username, prompt="username"):
                    while True:
                        password = input("Set your password (At least 7 characters): ")
                        if len(password) <= 6:
                            print("The password should at least sevenn characters, please try again.")
                            wait()
                            continue
                        else:
                            registeredUsername.append(username)
                            registeredPassword.append(password)
                            print("Registration successfully.")
                            wait()
                            break
                else:
                    continue
            else:
                continue
            break


# Login.
def login():
    if len(registeredUsername) == 0:
        print("Please register an account first before login..")
        wait()
    else:
        for attempt in range(3):
            loginUsername = input("Enter your username: ")
            loginPassword = input("Enter your password: ")
            if loginUsername not in registeredUsername:
                incorrect(attempt)
            else:
                indexPassword = registeredUsername.index(loginUsername)
                if not loginPassword == registeredPassword[indexPassword]:
                    incorrect(attempt)
                else:
                    print("Login successfully. Welcome back,", loginUsername + ".")
                    wait()
                    menu()


# When username or password is incorrect
def incorrect(attempt):
    if attempt == 2:
        print("Failure to login for three times, you have been terminated from the system!")
        wait()
        sys.exit()
    else:
        print("The username or password is incorrect, please enter again.")
        wait()


# Main menu.
def menu():
    while True:
        print("MENU")
        print("1. Store details.")
        print("2. Update details (Included receive and distribute items).")
        print("3. Track item.")
        print("4. Search item.")
        print("5. Print report.")
        print("6. Exit.")
        choice = input("Choose an option (1/2/3/4/5/6): ")
        if choice == "1":
            stores()
        elif choice == "2":
            validationStore()
            update()
        elif choice == "3":
            validationStore()
            track()
        elif choice == "4":
            validationStore()
            search()
        elif choice == "5":
            validationStore()
            printReport()
        elif choice == "6":
            end()
        else:
            invalid()


# Store detail.
def stores():
    while True:
        print("STORE")
        print("1. Store PPE details. ")
        print("2. Store supplier details. ")
        print("3. Store hospital details. ")
        print("4. Back. ")
        chooseWhat = input("Enter your choice please (1/2/3/4): ")
        if chooseWhat == "1":
            storePPE()
        elif chooseWhat == "2":
            storeSupplier()
        elif chooseWhat == "3":
            storeHospital()
        elif chooseWhat == "4":
            menu()
        else:
            invalid()


# Store item name, item code, supplier code, quantity, and unit price in ppe.txt.
def storePPE():
    if "CompletePPE" in store:
        restore(detail="PPE")
    else:
        quantity = int(100)
        printCodeName()
        for itemCode in range(len(ppeCode)):
            while True:
                supplierCode = input(f"Enter supplier code for {ppeCode[itemCode]}: ")
                if validationEmpty(answer=supplierCode, prompt="supplier code"):
                    if validationDuplicate(answer=supplierCode, existed=existSupplierCode, prompt="supplier code"):
                        existSupplierCode.append(supplierCode)
                        while True:
                            integerUnitPrice = input(f"Enter unit price (RM) for {ppeCode[itemCode]}: ")
                            if not integerUnitPrice.replace(".", "", 1).isdigit():
                                print("Unit Price must be float or integer.")
                                print("Please try again..")
                                wait()
                                continue
                            else:
                                floatUnitPrice = float(integerUnitPrice)
                                unitPrice = "{:.2f}".format(floatUnitPrice)
                                existUnitPrice.append(unitPrice)
                                existQuantity.append(quantity)
                                ppe = open("ppe.txt", "a")
                                ppe.write(f"{ppeCode[itemCode]:<15}{ppeName[itemCode]:<15}{quantity:<15}{supplierCode:<20}{unitPrice:<15}\n")
                                ppe.close()
                                break
                        break
                    else:
                        continue
                else:
                    continue
        else:
            print("Item names, item codes, supplier codes, quantity, and unit prices successful added.")
            store.append("CompletePPE")
            wait()
            stores()


# Restore detail.
def restore(detail):
    print(f"The {detail} details are already stored.")
    wait()
    while True:
        restoreAgain = input("Do you want to remove and restore the details again? (yes/no)")
        if restoreAgain.lower() == "yes":
            if detail == "PPE":
                ppe = open("ppe.txt", "w")
                ppe.write("")
                ppe.write(f"{"Item Code":<15}{"Item Name":<15}{"Quantity":<15}{"Supplier Code":<20}{"Unit Price (RM)":<15}\n")
                ppe.close()
                store.remove("CompletePPE")
                existUnitPrice.clear()
                existSupplierCode.clear()
                existQuantity.clear()
                storePPE()
            elif detail == "Supplier":
                supplier = open("suppliers.txt", "w")
                supplier.write("")
                supplier.close()
                store.remove("CompleteSup")
                existSupplierName.clear()
                typesSupplierName.clear()
                storeSupplier()
            else:
                hospital = open("hospitals.txt", "w")
                hospital.write("")
                hospital.close()
                store.remove("CompleteHos")
                existHospitalCode.clear()
                existHospitalName.clear()
                storeHospital()
        elif restoreAgain.lower() == "no":
            stores()
        else:
            invalid()


# Print item code and name.
def printCodeName():
    print("This is the PPE item code and name: ")
    print(f"{"Item Code":<15}{"Item Name":<15}")
    for indexesCode in range(len(ppeCode)):
        print(f"{ppeCode[indexesCode]:<15}{ppeName[indexesCode]:<15}")
    wait()


# Store supplier code, supplier name, and supplied PPE items in suppliers.txt.
def storeSupplier():
    if "CompleteSup" in store:
        restore(detail="Supplier")
    elif not existSupplierCode:
        print("Please store the PPE details first to prevent any error from occurring.")
        wait()
        stores()
    else:
        supplier = createFile("suppliers.txt")
        supplier.write(f"{"Supplier Code":<20}{"Supplier Name":<20}{"Supplied PPE Items":<20}\n")
        supplier.close()
        typeSupplier = ["first", "second", "third", "fourth"]
        for types in range(len(typeSupplier)):
            while True:
                typeSupplierName = input(f"Enter {typeSupplier[types]} supplier name: ")
                if validationEmpty(answer=typeSupplierName, prompt="supplier name"):
                    if validationDuplicate(answer=typeSupplierName, existed=typesSupplierName, prompt="supplier name"):
                        typesSupplierName.append(typeSupplierName)
                    else:
                        continue
                else:
                    continue
                break
        else:
            print(f"Available supplier name: {typesSupplierName}")
            for indicesItemsCode in range(len(ppeCode)):
                while True:
                    supplierName = input(f"Enter supplier name for {ppeCode[indicesItemsCode]}: ")
                    if validationValid(answer=supplierName, existed=typesSupplierName, prompt="supplier name"):
                        existSupplierName.append(supplierName)
                        supplier = open("suppliers.txt", "a")
                        supplier.write(f"{existSupplierCode[indicesItemsCode]:<20}{supplierName:<20}{ppeName[indicesItemsCode]:<20}\n")
                        supplier.close()
                        break
                    else:
                        continue
            else:
                print("Successful added the supplier name and supplied PPEs.")
                store.append("CompleteSup")
                wait()
                stores()


# Store hospital details in hospitals.txt.
def storeHospital():
    if "CompleteHos" in store:
        restore(detail="Hospital")
    else:
        hospital = createFile("hospitals.txt")
        hospital.write(f"{"Hospital Code":<15}{"Hospital Name":<15}\n")
        hospital.close()
        typeHospital = ["first", "second", "third", "fourth"]
        for indexHospital in range(4):
            while True:
                hospitalCode = input(f"Enter hospital code for {typeHospital[indexHospital]} hospital: ")
                if validationEmpty(answer=hospitalCode, prompt="hospital code"):
                    if validationDuplicate(answer=hospitalCode, existed=existHospitalCode, prompt="hospital code"):
                        existHospitalCode.append(hospitalCode)
                        while True:
                            hospitalName = input(f"Enter hospital name for {typeHospital[indexHospital]} hospital: ")
                            if validationEmpty(answer=hospitalName, prompt="hospital name"):
                                if validationDuplicate(answer=hospitalName, existed=existHospitalName,
                                                       prompt="hospital name"):
                                    existHospitalName.append(hospitalName)
                                    hospital = open("hospitals.txt", "a")
                                    hospital.write(f"{hospitalCode:<15}{hospitalName:<15}\n")
                                    hospital.close()
                                    break
                                else:
                                    continue
                            else:
                                continue
                        break
                    else:
                        continue
                else:
                    continue
        else:
            print("Hospital details successful stored.")
            wait()
            store.append("CompleteHos")
            stores()


# Check if details fully stored first.
def validationStore():
    if "CompletePPE" and "CompleteSup" and "CompleteHos" not in store:
        print("The details are not fully stored yet, please store the details first to prevent any error occurred. ")
        wait()
        menu()


# Update details
def update():
    while True:
        print("UPDATE")
        print("1. Receive item. ")
        print("2. Distribute item. ")
        print("3. Update suppliers details. ")
        print("4. Update hospitals details. ")
        print("5. Back. ")
        updateChoice = input("Choose an option (1/2/3/4/5): ")
        if updateChoice == "1":
            receivePPE()
        elif updateChoice == "2":
            distributePPE()
        elif updateChoice == "3":
            updateSupplier()
        elif updateChoice == "4":
            updateHospital()
        elif updateChoice == "5":
            menu()
        else:
            invalid()


# Receive PPE items and store in ppe.txt.
def receivePPE():
    while True:
        print("Available items: Head Cover, Face Shield, Shoe Covers, Mask, Gloves, Gown.")
        receiveItem = input("Enter item receive from suppliers: ")
        if validationValid(answer=receiveItem, existed=ppeName, prompt="PPE items"):
            while True:
                strReceivedQuantity = input("Enter quantity received: ")
                if validationDigit(answer=strReceivedQuantity):
                    receivedQuantity = int(strReceivedQuantity)
                    existReceiveItem.append(receiveItem)
                    existReceivedQuantity.append(receivedQuantity)
                    indexReceiveItems = ppeName.index(receiveItem)
                    existQuantity[indexReceiveItems] += receivedQuantity
                    rewritingPPE()
                    print(f"{receivedQuantity} boxes of {receiveItem} successfully received.")
                    store.append("CompleteReceive")
                    wait()
                    update()
                else:
                    continue
            break
        else:
            continue


# Update PPE details by rewriting.
def rewritingPPE():
    ppe = open("ppe.txt", "w")
    ppe.write("")
    ppe.write(f"{"Item Code":<15}{"Item Name":<15}{"Quantity":<15}{"Supplier Code":<20}{"Unit Price (RM)":<15}\n")
    for rewritePPE in range(len(ppeCode)):
        ppe.write(f"{ppeName[rewritePPE]:<15}{ppeCode[rewritePPE]:<15}{existQuantity[rewritePPE]:<15}{existSupplierCode[rewritePPE]:<20}{existUnitPrice[rewritePPE]:<15}\n")
    ppe.close()


# Distribute PPE Items and store hospital code, item code, item name, and distributed quantity in distribute.txt.
def distributePPE():
    if "CompleteDistribute" not in store:
        distribution = createFile("distribution.txt")
        distribution.write(f"{"Item Code":<15}{"Item Name":<15}{"Quantity":<15}{"Hospital Code":<15}\n")
        distribution.close()
    while True:
        print("Available items: Head Cover, Face Shield, Shoe Covers, Mask, Gloves, Gown.")
        distributedItems = input("Enter the PPE item to be distributed: ")
        if validationValid(answer=distributedItems, existed=ppeName, prompt="PPE items"):
            while True:
                strDistributedQuantity = input("Enter quantity: ")
                if validationDigit(answer=strDistributedQuantity):
                    distributedQuantity = int(strDistributedQuantity)
                    indexPPEName = ppeName.index(distributedItems)
                    if existQuantity[indexPPEName] < distributedQuantity:
                        print(f"{distributedItems} is insufficient currently, it has only remaining {existQuantity[indexPPEName]} of stock..")
                        wait()
                        update()
                    else:
                        existDistributionItem.append(distributedItems)
                        existDistributionQuantity.append(distributedQuantity)
                        existQuantity[indexPPEName] -= distributedQuantity
                        rewritingPPE()
                        while True:
                            printHospital()
                            hospitalCode = input("Enter hospital code that you want to distribute the PPE items to: ")
                            if validationValid(answer=hospitalCode, existed=existHospitalCode, prompt="hospital code"):
                                existDistributionHospital.append(hospitalCode)
                                distributedIndex = ppeName.index(distributedItems)
                                distributionCode = ppeCode[distributedIndex]
                                existDistributionCode.append(distributionCode)
                                distribution = open("distribution.txt", "a")
                                distribution.write(f"{distributionCode:<15}{distributedItems:<15}{distributedQuantity:<15}{hospitalCode:<15}\n")
                                distribution.close()
                                print(f"{distributedQuantity} boxes of {distributedItems}successfully distributed to {hospitalCode}.")
                                wait()
                                duplicateDistributionQuantity.append(distributedQuantity)
                                if distributionCode not in duplicateDistributionCode or hospitalCode not in duplicateDistributionHospital:
                                    duplicateDistributionCode.append(distributionCode)
                                    duplicateDistributionHospital.append(hospitalCode)
                                else:
                                    if distributionCode in duplicateDistributionCode:
                                        indexLatestCode = len(duplicateDistributionCode)
                                        indexDuplicateCode = duplicateDistributionCode.index(distributionCode)
                                        if hospitalCode in duplicateDistributionHospital:
                                            duplicateDistributionQuantity[indexDuplicateCode] += duplicateDistributionQuantity[indexLatestCode]
                                            duplicateDistributionQuantity.pop(indexLatestCode)
                                store.append("CompleteDistribute")
                                update()
                            else:
                                continue
                        break
                else:
                    continue
            break
        else:
            continue


# Update supplier details.
def updateSupplier():
    printSupplier()
    while True:
        updateWithSupCode = input("Enter the supplier code that you want to update: ")
        if validationValid(answer=updateWithSupCode, existed=existSupplierCode, prompt="supplier code"):
            while True:
                print("UPDATE SUPPLIER")
                print("1. Update the code.")
                print("2. Update the name.")
                print("3. Back.")
                updatingChoice = input("Choose an option (1/2/3): ")
                if updatingChoice == "1":
                    updateSupplierCode(updateWithSupCode)
                elif updatingChoice == "2":
                    updateSupplierName(updateWithSupCode)
                elif updatingChoice == "3":
                    update()
                else:
                    invalid()
        else:
            continue


# Update supplier code.
def updateSupplierCode(updateWithSupCode):
    while True:
        replacingCode = input(f"Enter the code that you want to replace {updateWithSupCode}: ")
        if validationEmpty(answer=replacingCode, prompt="supplier code"):
            indexSupCode = existSupplierCode.index(updateWithSupCode)
            existSupplierCode[indexSupCode] = replacingCode
            rewritingSuppliers()
            print(f"{updateWithSupCode} successfully replaced with {replacingCode}.")
            wait()
            update()
        else:
            continue


# Update supplier name.
def updateSupplierName(updateWithSupCode):
    while True:
        replacingName = input(f"Enter the name that you want to replace using {updateWithSupCode}: ")
        if validationEmpty(answer=replacingName, prompt="supplier name"):
            indexSupCode = existSupplierCode.index(updateWithSupCode)
            existSupplierName[indexSupCode] = replacingName
            rewritingSuppliers()
            print(f"The supplier name has been successfully replaced with {replacingName}.")
            wait()
            update()
        else:
            continue


# Update suppliers details by rewriting.
def rewritingSuppliers():
    supplier = open("suppliers.txt", "w")
    supplier.write("")
    supplier.write(f"{"Supplier Code":<20}{"Supplier Name":<20}{"Supplied PPE Items":<20}\n")
    for rewriteSuppliers in range(len(existSupplierCode)):
        supplier.write(f"{existSupplierCode[rewriteSuppliers]:<20}{existSupplierName[rewriteSuppliers]:<20}"
                       f"{ppeName[rewriteSuppliers]:<20}\n")
    supplier.close()


# Update hospital details in hospitals.txt.
def updateHospital():
    printHospital()
    while True:
        updateWithHosCode = input("Enter the hospital code that you want to update: ")
        if validationValid(answer=updateWithHosCode, existed=existHospitalCode, prompt="hospital code"):
            while True:
                print("UPDATE HOSPITAL")
                print("1. Update the code.")
                print("2. Update the name.")
                print("3. Back.")
                updateChoice = input("Choose an option (1/2/3): ")
                if updateChoice == "1":
                    updateHospitalCode(updateWithHosCode)
                elif updateChoice == "2":
                    updateHospitalName(updateWithHosCode)
                elif updateChoice == "3":
                    update()
                else:
                    invalid()


# Update hospital code.
def updateHospitalCode(updateWithHosCode):
    while True:
        replaceCode = input(f"Enter the code that you want to replace {updateWithHosCode}: ")
        if validationEmpty(answer=replaceCode, prompt="hospital code"):
            if validationDuplicate(answer=replaceCode, existed=existHospitalCode, prompt="hospital code"):
                indexHosCode = existHospitalCode.index(updateWithHosCode)
                existHospitalCode[indexHosCode] = replaceCode
                rewritingHospital()
                print(f"{updateWithHosCode} successfully replaced with {replaceCode}.")
                wait()
                update()
            else:
                continue
        else:
            continue


# Update hospital name.
def updateHospitalName(updateWithHosCode):
    while True:
        replaceName = input(f"Enter the name that you want to replace using {updateWithHosCode}: ")
        if validationEmpty(answer=replaceName, prompt="hospital name"):
            if validationDuplicate(answer=replaceName, existed=existHospitalName, prompt="hospital name"):
                indexHosCode = existHospitalCode.index(updateWithHosCode)
                existHospitalName[indexHosCode] = replaceName
                rewritingHospital()
                print(f"The hospital name has NOW been successfully replaced with {replaceName}.")
                wait()
                update()
            else:
                continue
        else:
            continue


# Update hospital details by rewriting.
def rewritingHospital():
    hospital = open("hospitals.txt", "w")
    hospital.write("")
    hospital.write(f"{"Hospital Code":<15}{"Hospital Name":<15}\n")
    for rewriteHospital in range(len(existHospitalCode)):
        hospital.write(f"{existHospitalCode[rewriteHospital]:<15}{existHospitalName[rewriteHospital]:<15}\n")
    hospital.close()


# Inventory item tracking.
def track():
    while True:
        print("TRACKING")
        print("1. Print total available quantity of all items sorted in ascending order by item code.")
        print("2. Print the records of all items that has stock quantity less than 25 boxes.")
        print("3. Back.")
        trackChoice = input("Select a choice: ")
        if trackChoice == "1":
            printAvailable()
        elif trackChoice == "2":
            quantityLessThan()
        elif trackChoice == "3":
            menu()
        else:
            invalid()


# Print total available quantity of all items sorted in ascending order by item code.
def printAvailable():
    print("This is the available quantity of all items in ascending order: ")
    wait()
    sortedPPEAll = sorted(zip(ppeCode, ppeName, existQuantity))
    sortedPPECode, sortedPPEName, sortedExistQuantity = zip(*sortedPPEAll)
    print(f"{"Item Code":<15}{"Item Name":<15}{"Quantity":<15}")
    for indexPrintAvailable in range(len(sortedPPECode)):
        print(f"{sortedPPECode[indexPrintAvailable]:<15}{sortedPPEName[indexPrintAvailable]:<15}{sortedExistQuantity[indexPrintAvailable]:<15}")
    wait()
    track()


# Print records of all items that has stock quantity less than 25 boxes.
def quantityLessThan():
    print("This is the records of all items with less than 25 boxes: ")
    wait()
    for findIndexQuantity in range(len(existQuantity)):
        if existQuantity[findIndexQuantity] < 25:
            quantityTracking.append(existQuantity[findIndexQuantity])
            codeTracking.append(ppeCode[findIndexQuantity])
            itemTracking.append(ppeName[findIndexQuantity])
    if len(quantityTracking) == 0:
        print("There is no items with stock quantity below 25 box.")
        wait()
        print(f"{"PPE Code":<15}{"PPE Item":<15}{"Quantity":<15}")
        for printAbove in range(len(ppeCode)):
            print(f"{ppeCode[printAbove]:<15}{ppeName[printAbove]:<15}{existQuantity[printAbove]:<15}")
    else:
        print(f"{"PPE Code":<15}{"PPE Item":<15}{"Quantity":<15}")
        for printLess in range(len(quantityTracking)):
            print(f"{codeTracking[printLess]:<15}{itemTracking[printLess]:<15}{quantityTracking[printLess]:<15}")
    quantityTracking.clear()
    codeTracking.clear()
    itemTracking.clear()
    wait()
    track()


# Search functionality.
def search():
    if "CompleteDistribute" not in store:
        print("Please distribute items to hospital first before searching distribution details.")
        wait()
        menu()
    while True:
        print(f"Available code: {duplicateDistributionCode}")
        searchUsingCode = input("Please enter the item code: ")
        if validationValid(answer=searchUsingCode, existed=duplicateDistributionCode, prompt="item code"):
            print(f"This is the hospital code and distributed quantity of {searchUsingCode}: ")
            wait()
            print(f"{"Hospital Code":<15}{"Quantity":<15}")
            for indexLoop in range(len(duplicateDistributionCode)):
                if duplicateDistributionCode[indexLoop] == searchUsingCode:
                    numOfLength.append(indexLoop)
            for detailSearching in numOfLength:
                print(f"{duplicateDistributionHospital[detailSearching]:<15}{duplicateDistributionQuantity[detailSearching]:<15}")
            wait()
            numOfLength.clear()
            menu()
        else:
            continue


# Report functionality.
def printReport():
    while True:
        print("REPORT")
        print("1. Print a list of suppliers with supplied PPE. ")
        print("2. Print a list of hospitals with quantity of distribution items. ")
        print("3. Print overall transaction report for a selected month. ")
        print("4. Print a list of PPE items remaining in the inventory. ")
        print("5. Print a list of hospitals. ")
        print("6. Back. ")
        choice = input("Select report type ( 1 / 2 / 3 / 4 / 5 / 6 ): ")
        if choice == "1":
            printSupplier()
        elif choice == "2":
            printDistribution()
        elif choice == "3":
            printTransaction()
        elif choice == "4":
            printPPE()
        elif choice == "5":
            printHospital()
        elif choice == "6":
            menu()
        else:
            invalid()


# Print suppliers.txt.
def printSupplier():
    print("This is the supplier code, supplier name, and supplied PPE items: ")
    printFile(fileName="suppliers.txt")


# Print distribution.txt.
def printDistribution():
    if "CompleteDistribute" not in store:
        print("Please distribute items to hospital first before checking distribution report.")
        wait()
        printReport()
    print("This is the list of item code, item name, quantity, and hospital code: ")
    printFile(fileName="distribution.txt")


# Print ppe.txt, suppliers.txt, and distribution.txt.
def printTransaction():
    if "CompleteReceive" and "CompleteDistribute" not in store:
        print("Please receive item from suppliers and distribute items to hospital first before checking transaction record.")
        wait()
        printReport()
    print("The overall transaction report for this month, August is: ")
    print("This is the report of PPE items received from suppliers: ")
    print(f"{"Receive Item":<15}{"Quantity":<15}{"Unit Price":<15}{"Supplier Code":<15}\n")
    for transactionReceivedPrint in range(len(existReceiveItem)):
        print(f"{existReceiveItem[transactionReceivedPrint]:<15}{existReceivedQuantity[transactionReceivedPrint]:<15}{existUnitPrice[transactionReceivedPrint]:<15}{existSupplierCode[transactionReceivedPrint]:<15}\n")
    wait()
    for indexReceive in range(len(existReceivedQuantity)):
        print(f"From table above, we can know that we have received {existReceivedQuantity[indexReceive]} {existReceiveItem[indexReceive]} from {existSupplierCode[indexReceive]} with the price of {existUnitPrice[indexReceive]} per box.")
    wait()
    print("This is the report of PPE items distributed to hospitals: ")
    printDistribution()
    totalReceivedQuantity = countSum(existReceivedQuantity)
    totalDistributedQuantity = countSum(existDistributionQuantity)
    differences = totalDistributedQuantity - totalReceivedQuantity
    for indexDistribute in range(len(existDistributionQuantity)):
        print(f"From table above, we can know that we have distributed {existDistributionQuantity[indexDistribute]} {existDistributionItem[indexDistribute]} to {existDistributionHospital[indexDistribute]}.")
    wait()
    print(f"In conclude, Spend: {totalReceivedQuantity}, Get: {totalDistributedQuantity}, Difference: {differences}.")


# Sums up all the prices.
def countSum(quantity):
    total = 0
    for countQuantity, countPrice in zip(quantity, existUnitPrice):
        total += int(countQuantity) * int(float(countPrice))
    return total


# Print ppe.txt.
def printPPE():
    print("This is the item code, item name, quantity, supplier code and price: ")
    printFile(fileName="ppe.txt")


# View hospital details in hospitals.txt.
def printHospital():
    print("This is the hospital code and name: ")
    printFile(fileName="hospitals.txt")


# Print details from file...
def printFile(fileName):
    filePrints = open(fileName, "r")
    for printsFile in filePrints:
        print(printsFile.strip())
    wait()


start()
